/**
 * Sample React Native App
 * https://github.com/facebook/react-native
 *
 * @format
 */

import React, { useEffect } from 'react';
import {
  StatusBar,
  StyleSheet,
  useColorScheme,
  View,
  TouchableOpacity,
  Text,
  ScrollView,
} from 'react-native';
import {
  SafeAreaProvider,
  useSafeAreaInsets,
} from 'react-native-safe-area-context';
import { NavigationContainer } from '@react-navigation/native';
import { createNativeStackNavigator } from '@react-navigation/native-stack';
import { NewAppScreen } from '@react-native/new-app-screen';
import WebhookScreen from './components/WebhookScreen';
import ClientesTable from './components/ClientesTable';
import WebhookManager from './services/WebhookManager';
import SyncService from './services/SyncService';

const Stack = createNativeStackNavigator();

function App() {
  const isDarkMode = useColorScheme() === 'dark';

  useEffect(() => {
    // Inicializar servicios al iniciar la app
    Promise.all([WebhookManager.initialize(), SyncService.initialize()]).catch(
      console.error,
    );
  }, []);

  return (
    <SafeAreaProvider>
      <StatusBar barStyle={isDarkMode ? 'light-content' : 'dark-content'} />
      <NavigationContainer>
        <Stack.Navigator initialRouteName="Home">
          <Stack.Screen
            name="Home"
            component={AppContent}
            options={{ title: 'Awesome App' }}
          />
          <Stack.Screen
            name="Webhooks"
            component={WebhookScreen}
            options={{ title: 'Webhooks Managers' }}
          />
          <Stack.Screen
            name="Clientes"
            component={ClientesTable}
            options={{ title: 'Clientes Sincronizados' }}
          />
        </Stack.Navigator>
      </NavigationContainer>
    </SafeAreaProvider>
  );
}

function AppContent({ navigation }) {
  const safeAreaInsets = useSafeAreaInsets();

  return (
    <ScrollView style={styles.container}>
      <View style={styles.content}>
        <NewAppScreen path="/Users/luissantosgaona/AwesomeProject/App.tsx" />

        {/* Botones de navegación */}
        <View style={styles.buttonsContainer}>
          <TouchableOpacity
            style={styles.webhookButton}
            onPress={() => navigation.navigate('Webhooks')}
          >
            <Text style={styles.webhookButtonText}>📡 Gestionar Webhooks</Text>
          </TouchableOpacity>

          <TouchableOpacity
            style={styles.clientesButton}
            onPress={() => navigation.navigate('Clientes')}
          >
            <Text style={styles.clientesButtonText}>👥 Ver Clientes</Text>
          </TouchableOpacity>
        </View>
      </View>
    </ScrollView>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#f5f5f5',
  },
  content: {
    flex: 1,
  },
  buttonsContainer: {
    paddingHorizontal: 20,
    paddingBottom: 30,
    paddingTop: 20,
  },
  webhookButton: {
    backgroundColor: '#2196F3',
    paddingHorizontal: 20,
    paddingVertical: 15,
    borderRadius: 25,
    shadowColor: '#000',
    shadowOffset: {
      width: 0,
      height: 2,
    },
    shadowOpacity: 0.25,
    shadowRadius: 3.84,
    elevation: 5,
    marginBottom: 15,
  },
  webhookButtonText: {
    color: '#fff',
    fontSize: 16,
    fontWeight: 'bold',
    textAlign: 'center',
  },
  clientesButton: {
    backgroundColor: '#4CAF50',
    paddingHorizontal: 20,
    paddingVertical: 15,
    borderRadius: 25,
    shadowColor: '#000',
    shadowOffset: {
      width: 0,
      height: 2,
    },
    shadowOpacity: 0.25,
    shadowRadius: 3.84,
    elevation: 5,
  },
  clientesButtonText: {
    color: '#fff',
    fontSize: 16,
    fontWeight: 'bold',
    textAlign: 'center',
  },
});

export default App;
